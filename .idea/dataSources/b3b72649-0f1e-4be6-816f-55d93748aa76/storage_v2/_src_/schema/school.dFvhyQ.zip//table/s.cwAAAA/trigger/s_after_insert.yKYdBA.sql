create definer = root@localhost trigger s_AFTER_INSERT
    after INSERT
    on s
    for each row
BEGIN
    call jia();
END;

