create definer = root@localhost trigger E_ZPCJ
    before UPDATE
    on e
    for each row
begin
    set  @rati = (select ratio from xishu where id = 1);
    set new.zpcj=new.pscj * @rati + new.kscj * (1 - @rati);
end;

