create
    definer = root@localhost procedure sub()
BEGIN
    update count1 set num=num-1;
END;

