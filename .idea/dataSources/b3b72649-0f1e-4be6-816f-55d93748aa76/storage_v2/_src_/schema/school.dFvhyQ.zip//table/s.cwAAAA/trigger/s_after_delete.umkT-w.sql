create definer = root@localhost trigger s_AFTER_DELETE
    after DELETE
    on s
    for each row
BEGIN
    call sub();
END;

